class Employee:
    def __int__(self, first, last, pay):
        self.first = first
        self.last = last
        self.pay = pay
        self.email = first + "." + last + "@company.com"

    def fullname(self):
        return {self.first}, {self.last}

emp1 = Employee("Sam", "Ayo", 2000)
emp1.fullname()