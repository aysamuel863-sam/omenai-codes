class Character:
    def __init__(self, name, health, level):
        self.name = name
        self.health = health
        self.level = level

    def introduce(self):
        print("Name: ", self.name)
        print("Health: ", self.health)
        print("Level: ", self.level)
        
    def level_up(self):    
        self.level += 1
        print(self.name, "leveled up!")    
        print(self.name, "is now in level", self.level,".")

    def take_damage(self, damage):
            self.health -= damage
    
            if self.health < 0:
                self.health = 0
            print(self.name, "took", damage, "damage!")
            print(self.name, "has", self.health, "health.")

    def heal(self):
        self.health += 20
        print(self.name, "healed!")
        print(self.name, "now has", self.health, "health.")

player = Character("Shadow", 100, 1)

player.introduce()
player.level_up()
player.take_damage(40)
player.heal()
