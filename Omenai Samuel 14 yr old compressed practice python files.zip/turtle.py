#import turtlei
#t = turtle.Turtle("circle")
#t.speed(67)
import six
print(2^2)